﻿/*
*	<copyright file="Program.cs" company="IPCA">
*		Copyright (c) 2020 All Rights Reserved
*	</copyright>
* 	<author>lufer</author>
*   <date>5/15/2020 11:27:32 AM</date>
*	<description>
*	MVC Example:
*	Adapted from 
*	http://congeritc.blogspot.com/2013/01/mvc-example-with-c-console-program.html
*	</description>
**/
namespace MVCSample
{
    class Program
    {
        static void Main(string[] args)
        {
            TipCalculatorController t = new TipCalculatorController();
        }
    }
}
