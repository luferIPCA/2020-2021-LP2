﻿using MVC_II.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVC_II
{
    class Program
    {
        static void Main(string[] args)
        {
            ControlaPandemic control = new ControlaPandemic();
            Console.ReadKey();
        }
    }
}
