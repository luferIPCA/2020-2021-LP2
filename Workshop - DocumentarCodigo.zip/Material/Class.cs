﻿/*
*	<copyright file="$safeitemname$.cs" company="IPCA">
*		Copyright (c) $year$ All Rights Reserved
*	</copyright>
* 	<author>$username$</author>
*   <date>$time$</date>
*	<description></description>
**/
using System;
using System.Collections.Generic;
$if$ ($targetframeworkversion$ >= 3.5)using System.Linq;
$endif$using System.Text;
 
namespace $rootnamespace$
{
	/// <summary>
    /// Purpose:
    /// Created by: $username$
    /// Created on: $time$
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    public class $safeitemrootname$
    {
        #region Attributes
        #endregion
 
		#region Methods
		
        #region Constructors
 
        /// <summary>
        /// The default Constructor.
        /// </summary>
        public $safeitemrootname$()
        {
        }
 
        #endregion
 
        #region Properties
        #endregion
 
        #region Functions
        #endregion
 
        #region Overrides
        #endregion
		
		#region Destructor
		/// <summary>
        /// The destructor.
        /// </summary>
		~$safeitemrootname$()
        {
        }
		#endregion

		#endregion
    }
}
