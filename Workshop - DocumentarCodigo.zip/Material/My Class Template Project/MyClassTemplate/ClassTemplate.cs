﻿/*
*	<copyright file="$rootnamespace$.cs" company="IPCA">
*		Copyright (c) $year$ All Rights Reserved
*	</copyright>
* 	<author>$username$</author>
*   <date>$time$</date>
*	<description></description>
**/
using System;

namespace $rootnamespace$
{
    /// <summary>
    /// Purpose:
    /// Created by: $username$
    /// Created on: $time$
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    public class $safeitemrootname$
    {
        #region Attributes
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// The default Constructor.
        /// </summary>
        public $safeitemrootname$()
        {
        }

        #endregion

        #region Properties
        #endregion

        #region Overrides
        #endregion

        #region OtherMethods
        #endregion

        #region Destructor
        /// <summary>
        /// The destructor
        /// </summary>
        ~$safeitemrootname$()
        {
        }
        #endregion

        #endregion
    }
}
