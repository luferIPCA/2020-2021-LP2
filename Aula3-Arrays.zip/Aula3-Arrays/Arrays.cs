﻿/*
 * Metodos para manipular arrays
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula3_Arrays
{
    class Arrays
    {
        /// <summary>
        /// Verifica se uma valor existe num array
        /// </summary>
        /// <param name="valores">Valores a analisar</param>
        /// <param name="valor">Valor a comparar</param>
        /// <returns></returns>
        public static bool Existe(int[] v, int valor)
        {
            bool existe = false;
            foreach (int a in v)
            {
                if (a == valor)
                {
                    existe = true;
                    break;
                }
            }
            //for(int i=0; i<valores.Length; i++)
            //{
            //    if (valores[i]==valor)...
            //}

            return existe;
        }

        /// <summary>
        /// Incrementa um determinado valor a todos os calores do array
        /// </summary>
        /// <param name="v"></param>
        /// <param name="valorIncrementar"></param>
        public static void Incrementa(int[] v, int valorIncrementar)
        {
            for (int i = 0; i < v.Length; i++)
                v[i] += valorIncrementar;
        }

        public static void MostraArray(int[] v)
        {
            foreach (int a in v) Console.WriteLine(a);
        }
    }
}
