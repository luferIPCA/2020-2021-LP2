﻿/*
*	<copyright file="Aula3_Arrays.cs" company="IPCA">
*		Copyright (c) 2021 All Rights Reserved
*	</copyright>
* 	<author>lufer</author>
*   <date>3/4/2021 9:28:59 PM</date>
*	<description></description>
**/
using System;

namespace Aula3_Arrays
{
    /// <summary>
    /// Purpose:
    /// Created by: lufer
    /// Created on: 3/4/2021 9:28:59 PM
    /// </summary>
    /// <remarks></remarks>
    /// <example></example>
    public class Minha
    {
        #region Attributes
        #endregion

        #region Methods

        #region Constructors

        /// <summary>
        /// The default Constructor.
        /// </summary>
        public Minha()
        {
        }

        #endregion

        #region Properties
        #endregion



        #region Overrides
        #endregion

        #region OtherMethods
        #endregion

        #region Destructor
        /// <summary>
        /// The destructor.
        /// </summary>
        ~Minha()
        {
        }
        #endregion

        #endregion
    }
}
